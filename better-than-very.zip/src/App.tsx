/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Search, 
  Copy, 
  Check, 
  History, 
  Sparkles, 
  ArrowRight,
  RefreshCw,
  Trash2,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Types
interface Transformation {
  id: string;
  input: string;
  output: string;
  usageNote?: string;
  timestamp: number;
}

const SYSTEM_INSTRUCTION = `You are the engine for the "Better Than Very" app. Your goal is to replace phrases containing the word "very" (e.g., "very happy," "very sad," "very fast") with a single-word intensive synonym.

1. Provide the single-word intensive synonym.
2. Additionally, provide a brief 'Usage Note' that includes:
   - One example sentence using the new word.
   - A short description of the specific situation or nuance where this word is best used compared to the original 'very' phrase.

CRITICAL: The synonym must be a direct grammatical drop-in for the "very [word]" phrase.

OUTPUT FORMAT:
[Synonym]
[Usage Note]

Example:
Ecstatic
She was ecstatic when she heard the news. This word conveys a higher level of joy than "very happy," often implying a state of overwhelming excitement or bliss.`;

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<{ word: string; note: string } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<Transformation[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('btv_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('btv_history', JSON.stringify(history));
  }, [history]);

  const handleTransform = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const normalizedInput = input.trim().toLowerCase();
    if (!normalizedInput.includes('very')) {
      setError('Please include the word "very" in your phrase.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: normalizedInput,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          temperature: 0.1, // Low temperature for consistent synonyms
        },
      });

      const text = response.text?.trim();
      
      if (text) {
        const lines = text.split('\n').filter(l => l.trim());
        const word = lines[0].trim();
        const note = lines.slice(1).join('\n').trim();

        setResult({ word, note });
        const newEntry: Transformation = {
          id: Math.random().toString(36).substring(7),
          input: normalizedInput,
          output: word,
          usageNote: note,
          timestamp: Date.now(),
        };
        setHistory(prev => [newEntry, ...prev.slice(0, 19)]); // Keep last 20
      } else {
        setError("Couldn't find a better word. Try another phrase.");
      }
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const handleHistoryItemClick = (item: Transformation) => {
    setInput(item.input);
    setResult({ word: item.output, note: item.usageNote || '' });
    setError(null);
  };

  const handleReset = () => {
    setInput('');
    setResult(null);
    setError(null);
    inputRef.current?.focus();
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] text-[#1A1A1A] font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Header */}
      <header className="max-w-4xl mx-auto pt-12 px-6 flex justify-between items-end">
        <div>
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 text-emerald-600 mb-2"
          >
            <Sparkles size={18} />
            <span className="text-xs font-bold uppercase tracking-widest">Vocabulary Engine</span>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-bold tracking-tight"
          >
            Better Than <span className="text-emerald-600">Very</span>.
          </motion.h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Main Interaction Area */}
          <div className="lg:col-span-2 space-y-8">
            <section className="bg-white rounded-3xl p-8 shadow-sm border border-black/5">
              <form onSubmit={handleTransform} className="space-y-6">
                <div className="relative">
                  <label htmlFor="phrase-input" className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
                    Your Phrase
                  </label>
                  <div className="relative group">
                    <input
                      id="phrase-input"
                      ref={inputRef}
                      type="text"
                      value={input}
                      onChange={(e) => {
                        setInput(e.target.value);
                        if (error) setError(null);
                      }}
                      placeholder="e.g., very happy"
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-emerald-500/20 focus:bg-white rounded-2xl pl-6 pr-24 py-5 text-xl outline-none transition-all placeholder:text-gray-300"
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                      {input && !isLoading && (
                        <button
                          type="button"
                          onClick={() => setInput('')}
                          className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          <X size={20} />
                        </button>
                      )}
                      <button
                        type="submit"
                        disabled={isLoading || !input.trim()}
                        className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-200 text-white p-3 rounded-xl transition-all shadow-lg shadow-emerald-600/20 disabled:shadow-none"
                      >
                        {isLoading ? (
                          <RefreshCw className="animate-spin" size={24} />
                        ) : (
                          <ArrowRight size={24} />
                        )}
                      </button>
                    </div>
                  </div>
                  {error && (
                    <motion.p 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-500 text-sm mt-2 ml-1"
                    >
                      {error}
                    </motion.p>
                  )}
                </div>
              </form>

              <AnimatePresence mode="wait">
                {result && (
                  <motion.div
                    key={result.word}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="mt-12 pt-12 border-t border-gray-100 flex flex-col items-center"
                  >
                    <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-4">The Better Word</span>
                    <div className="relative group text-center mb-8">
                      <h2 className="text-6xl md:text-7xl font-bold tracking-tighter text-emerald-950 mb-6">
                        {result.word}
                      </h2>
                      <div className="flex flex-wrap items-center justify-center gap-4">
                        <button
                          onClick={() => copyToClipboard(result.word)}
                          className="flex items-center gap-2 bg-gray-900 text-white px-6 py-3 rounded-full hover:bg-black transition-all active:scale-95"
                        >
                          {copied ? <Check size={18} /> : <Copy size={18} />}
                          <span className="font-medium">{copied ? 'Copied!' : 'Copy Word'}</span>
                        </button>
                        <button
                          onClick={handleReset}
                          className="flex items-center gap-2 bg-white text-gray-900 border border-gray-200 px-6 py-3 rounded-full hover:bg-gray-50 transition-all active:scale-95"
                        >
                          <RefreshCw size={18} />
                          <span className="font-medium">Try Another</span>
                        </button>
                      </div>
                    </div>

                    {result.note && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="w-full bg-emerald-50/50 rounded-2xl p-6 border border-emerald-100/50"
                      >
                        <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm mb-3">
                          <Sparkles size={14} />
                          <span>Usage Note</span>
                        </div>
                        <div className="text-emerald-900/80 text-sm leading-relaxed whitespace-pre-wrap">
                          {result.note}
                        </div>
                      </motion.div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </section>

            {/* Tips Section */}
            <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100">
                <h3 className="font-bold text-emerald-900 mb-2">Why use synonyms?</h3>
                <p className="text-emerald-800/70 text-sm leading-relaxed">
                  "Very" is a lazy word. Using precise vocabulary makes your writing more evocative, professional, and impactful.
                </p>
              </div>
              <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
                <h3 className="font-bold text-blue-900 mb-2">Pro Tip</h3>
                <p className="text-blue-800/70 text-sm leading-relaxed">
                  Try phrases like "very tired" (exhausted), "very big" (colossal), or "very small" (minuscule).
                </p>
              </div>
            </section>
          </div>

          {/* Sidebar: History */}
          <aside className="space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-black/5 h-full flex flex-col">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2 text-gray-900 font-bold">
                  <History size={18} />
                  <span>Recent</span>
                </div>
                {history.length > 0 && (
                  <button 
                    onClick={clearHistory}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                    title="Clear history"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>

              <div className="space-y-3 overflow-y-auto max-h-[500px] pr-2 custom-scrollbar">
                <AnimatePresence initial={false}>
                  {history.length === 0 ? (
                    <p className="text-gray-400 text-sm text-center py-12 italic">No history yet</p>
                  ) : (
                    history.map((item) => (
                      <motion.button
                        key={item.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        onClick={() => handleHistoryItemClick(item)}
                        className="w-full text-left p-4 rounded-2xl hover:bg-gray-50 border border-transparent hover:border-gray-100 transition-all group"
                      >
                        <div className="text-xs text-gray-400 mb-1 flex justify-between">
                          <span>{item.input}</span>
                          <span className="opacity-0 group-hover:opacity-100 transition-opacity">
                            {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div className="font-bold text-gray-900 group-hover:text-emerald-600 transition-colors">
                          {item.output}
                        </div>
                      </motion.button>
                    ))
                  )}
                </AnimatePresence>
              </div>
            </div>
          </aside>
        </div>
      </main>

      <footer className="max-w-4xl mx-auto px-6 py-12 border-t border-gray-200 mt-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 text-gray-400 text-sm">
          <p>© {new Date().getFullYear()} Better Than Very. Write with precision.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-gray-900 transition-colors">Privacy</a>
            <a href="#" className="hover:text-gray-900 transition-colors">Terms</a>
            <a href="#" className="hover:text-gray-900 transition-colors">Contact</a>
          </div>
        </div>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #E5E7EB;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #D1D5DB;
        }
      `}</style>
    </div>
  );
}
